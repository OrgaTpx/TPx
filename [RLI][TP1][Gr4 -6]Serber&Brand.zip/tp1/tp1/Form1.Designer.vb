﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tb_result = New System.Windows.Forms.TextBox()
        Me.b_seven = New System.Windows.Forms.Button()
        Me.b_four = New System.Windows.Forms.Button()
        Me.b_one = New System.Windows.Forms.Button()
        Me.b_eight = New System.Windows.Forms.Button()
        Me.b_five = New System.Windows.Forms.Button()
        Me.b_two = New System.Windows.Forms.Button()
        Me.b_nine = New System.Windows.Forms.Button()
        Me.b_six = New System.Windows.Forms.Button()
        Me.b_three = New System.Windows.Forms.Button()
        Me.b_zero = New System.Windows.Forms.Button()
        Me.b_coma = New System.Windows.Forms.Button()
        Me.b_changesign = New System.Windows.Forms.Button()
        Me.b_slash = New System.Windows.Forms.Button()
        Me.b_star = New System.Windows.Forms.Button()
        Me.b_minus = New System.Windows.Forms.Button()
        Me.b_plus = New System.Windows.Forms.Button()
        Me.b_back = New System.Windows.Forms.Button()
        Me.b_ce = New System.Windows.Forms.Button()
        Me.b_c = New System.Windows.Forms.Button()
        Me.b_equal = New System.Windows.Forms.Button()
        Me.b_inverse = New System.Windows.Forms.Button()
        Me.b_pourcent = New System.Windows.Forms.Button()
        Me.b_sqrt = New System.Windows.Forms.Button()
        Me.tb_buffer = New System.Windows.Forms.TextBox()
        Me.b_mc = New System.Windows.Forms.Button()
        Me.b_mr = New System.Windows.Forms.Button()
        Me.b_ms = New System.Windows.Forms.Button()
        Me.b_mplus = New System.Windows.Forms.Button()
        Me.b_mmoins = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'tb_result
        '
        Me.tb_result.Location = New System.Drawing.Point(12, 12)
        Me.tb_result.Name = "tb_result"
        Me.tb_result.Size = New System.Drawing.Size(195, 20)
        Me.tb_result.TabIndex = 0
        Me.tb_result.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'b_seven
        '
        Me.b_seven.Location = New System.Drawing.Point(12, 114)
        Me.b_seven.Name = "b_seven"
        Me.b_seven.Size = New System.Drawing.Size(31, 20)
        Me.b_seven.TabIndex = 1
        Me.b_seven.Text = "7"
        Me.b_seven.UseVisualStyleBackColor = True
        '
        'b_four
        '
        Me.b_four.Location = New System.Drawing.Point(12, 140)
        Me.b_four.Name = "b_four"
        Me.b_four.Size = New System.Drawing.Size(31, 20)
        Me.b_four.TabIndex = 2
        Me.b_four.Text = "4"
        Me.b_four.UseVisualStyleBackColor = True
        '
        'b_one
        '
        Me.b_one.Location = New System.Drawing.Point(12, 166)
        Me.b_one.Name = "b_one"
        Me.b_one.Size = New System.Drawing.Size(31, 20)
        Me.b_one.TabIndex = 3
        Me.b_one.Text = "1"
        Me.b_one.UseVisualStyleBackColor = True
        '
        'b_eight
        '
        Me.b_eight.Location = New System.Drawing.Point(50, 114)
        Me.b_eight.Name = "b_eight"
        Me.b_eight.Size = New System.Drawing.Size(40, 20)
        Me.b_eight.TabIndex = 4
        Me.b_eight.Text = "8"
        Me.b_eight.UseVisualStyleBackColor = True
        '
        'b_five
        '
        Me.b_five.Location = New System.Drawing.Point(50, 140)
        Me.b_five.Name = "b_five"
        Me.b_five.Size = New System.Drawing.Size(40, 20)
        Me.b_five.TabIndex = 5
        Me.b_five.Text = "5"
        Me.b_five.UseVisualStyleBackColor = True
        '
        'b_two
        '
        Me.b_two.Location = New System.Drawing.Point(50, 166)
        Me.b_two.Name = "b_two"
        Me.b_two.Size = New System.Drawing.Size(40, 20)
        Me.b_two.TabIndex = 6
        Me.b_two.Text = "2"
        Me.b_two.UseVisualStyleBackColor = True
        '
        'b_nine
        '
        Me.b_nine.Location = New System.Drawing.Point(97, 114)
        Me.b_nine.Name = "b_nine"
        Me.b_nine.Size = New System.Drawing.Size(26, 20)
        Me.b_nine.TabIndex = 7
        Me.b_nine.Text = "9"
        Me.b_nine.UseVisualStyleBackColor = True
        '
        'b_six
        '
        Me.b_six.Location = New System.Drawing.Point(97, 140)
        Me.b_six.Name = "b_six"
        Me.b_six.Size = New System.Drawing.Size(26, 20)
        Me.b_six.TabIndex = 8
        Me.b_six.Text = "6"
        Me.b_six.UseVisualStyleBackColor = True
        '
        'b_three
        '
        Me.b_three.Location = New System.Drawing.Point(97, 166)
        Me.b_three.Name = "b_three"
        Me.b_three.Size = New System.Drawing.Size(26, 20)
        Me.b_three.TabIndex = 9
        Me.b_three.Text = "3"
        Me.b_three.UseVisualStyleBackColor = True
        '
        'b_zero
        '
        Me.b_zero.Location = New System.Drawing.Point(12, 192)
        Me.b_zero.Name = "b_zero"
        Me.b_zero.Size = New System.Drawing.Size(58, 20)
        Me.b_zero.TabIndex = 10
        Me.b_zero.Text = "0"
        Me.b_zero.UseVisualStyleBackColor = True
        '
        'b_coma
        '
        Me.b_coma.Location = New System.Drawing.Point(77, 192)
        Me.b_coma.Name = "b_coma"
        Me.b_coma.Size = New System.Drawing.Size(46, 20)
        Me.b_coma.TabIndex = 11
        Me.b_coma.Text = ","
        Me.b_coma.UseVisualStyleBackColor = True
        '
        'b_changesign
        '
        Me.b_changesign.Location = New System.Drawing.Point(131, 88)
        Me.b_changesign.Name = "b_changesign"
        Me.b_changesign.Size = New System.Drawing.Size(34, 20)
        Me.b_changesign.TabIndex = 12
        Me.b_changesign.Text = "+/-"
        Me.b_changesign.UseVisualStyleBackColor = True
        '
        'b_slash
        '
        Me.b_slash.Location = New System.Drawing.Point(131, 114)
        Me.b_slash.Name = "b_slash"
        Me.b_slash.Size = New System.Drawing.Size(34, 20)
        Me.b_slash.TabIndex = 13
        Me.b_slash.Text = "/"
        Me.b_slash.UseVisualStyleBackColor = True
        '
        'b_star
        '
        Me.b_star.Location = New System.Drawing.Point(131, 140)
        Me.b_star.Name = "b_star"
        Me.b_star.Size = New System.Drawing.Size(34, 20)
        Me.b_star.TabIndex = 14
        Me.b_star.Text = "*"
        Me.b_star.UseVisualStyleBackColor = True
        '
        'b_minus
        '
        Me.b_minus.Location = New System.Drawing.Point(131, 166)
        Me.b_minus.Name = "b_minus"
        Me.b_minus.Size = New System.Drawing.Size(34, 20)
        Me.b_minus.TabIndex = 15
        Me.b_minus.Text = "-"
        Me.b_minus.UseVisualStyleBackColor = True
        '
        'b_plus
        '
        Me.b_plus.Location = New System.Drawing.Point(131, 192)
        Me.b_plus.Name = "b_plus"
        Me.b_plus.Size = New System.Drawing.Size(34, 20)
        Me.b_plus.TabIndex = 16
        Me.b_plus.Text = "+"
        Me.b_plus.UseVisualStyleBackColor = True
        '
        'b_back
        '
        Me.b_back.Location = New System.Drawing.Point(12, 88)
        Me.b_back.Name = "b_back"
        Me.b_back.Size = New System.Drawing.Size(31, 20)
        Me.b_back.TabIndex = 17
        Me.b_back.Text = "<-"
        Me.b_back.UseVisualStyleBackColor = True
        '
        'b_ce
        '
        Me.b_ce.Location = New System.Drawing.Point(50, 88)
        Me.b_ce.Name = "b_ce"
        Me.b_ce.Size = New System.Drawing.Size(40, 20)
        Me.b_ce.TabIndex = 18
        Me.b_ce.Text = "CE"
        Me.b_ce.UseVisualStyleBackColor = True
        '
        'b_c
        '
        Me.b_c.Location = New System.Drawing.Point(97, 88)
        Me.b_c.Name = "b_c"
        Me.b_c.Size = New System.Drawing.Size(27, 20)
        Me.b_c.TabIndex = 19
        Me.b_c.Text = "C"
        Me.b_c.UseVisualStyleBackColor = True
        '
        'b_equal
        '
        Me.b_equal.Location = New System.Drawing.Point(172, 166)
        Me.b_equal.Name = "b_equal"
        Me.b_equal.Size = New System.Drawing.Size(34, 46)
        Me.b_equal.TabIndex = 24
        Me.b_equal.Text = "="
        Me.b_equal.UseVisualStyleBackColor = True
        '
        'b_inverse
        '
        Me.b_inverse.Location = New System.Drawing.Point(172, 140)
        Me.b_inverse.Name = "b_inverse"
        Me.b_inverse.Size = New System.Drawing.Size(34, 20)
        Me.b_inverse.TabIndex = 22
        Me.b_inverse.Text = "1/x"
        Me.b_inverse.UseVisualStyleBackColor = True
        '
        'b_pourcent
        '
        Me.b_pourcent.Location = New System.Drawing.Point(172, 114)
        Me.b_pourcent.Name = "b_pourcent"
        Me.b_pourcent.Size = New System.Drawing.Size(34, 20)
        Me.b_pourcent.TabIndex = 21
        Me.b_pourcent.Text = "%"
        Me.b_pourcent.UseVisualStyleBackColor = True
        '
        'b_sqrt
        '
        Me.b_sqrt.Location = New System.Drawing.Point(172, 88)
        Me.b_sqrt.Name = "b_sqrt"
        Me.b_sqrt.Size = New System.Drawing.Size(34, 20)
        Me.b_sqrt.TabIndex = 20
        Me.b_sqrt.Text = "RAC"
        Me.b_sqrt.UseVisualStyleBackColor = True
        '
        'tb_buffer
        '
        Me.tb_buffer.Location = New System.Drawing.Point(12, 37)
        Me.tb_buffer.Name = "tb_buffer"
        Me.tb_buffer.Size = New System.Drawing.Size(195, 20)
        Me.tb_buffer.TabIndex = 25
        Me.tb_buffer.Text = "0"
        Me.tb_buffer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'b_mc
        '
        Me.b_mc.Location = New System.Drawing.Point(12, 59)
        Me.b_mc.Name = "b_mc"
        Me.b_mc.Size = New System.Drawing.Size(31, 20)
        Me.b_mc.TabIndex = 26
        Me.b_mc.Text = "MC"
        Me.b_mc.UseVisualStyleBackColor = True
        '
        'b_mr
        '
        Me.b_mr.Location = New System.Drawing.Point(50, 59)
        Me.b_mr.Name = "b_mr"
        Me.b_mr.Size = New System.Drawing.Size(40, 20)
        Me.b_mr.TabIndex = 27
        Me.b_mr.Text = "MR"
        Me.b_mr.UseVisualStyleBackColor = True
        '
        'b_ms
        '
        Me.b_ms.Location = New System.Drawing.Point(96, 59)
        Me.b_ms.Name = "b_ms"
        Me.b_ms.Size = New System.Drawing.Size(29, 20)
        Me.b_ms.TabIndex = 28
        Me.b_ms.Text = "MS"
        Me.b_ms.UseVisualStyleBackColor = True
        '
        'b_mplus
        '
        Me.b_mplus.Location = New System.Drawing.Point(131, 59)
        Me.b_mplus.Name = "b_mplus"
        Me.b_mplus.Size = New System.Drawing.Size(34, 20)
        Me.b_mplus.TabIndex = 29
        Me.b_mplus.Text = "M+"
        Me.b_mplus.UseVisualStyleBackColor = True
        '
        'b_mmoins
        '
        Me.b_mmoins.Location = New System.Drawing.Point(172, 59)
        Me.b_mmoins.Name = "b_mmoins"
        Me.b_mmoins.Size = New System.Drawing.Size(34, 20)
        Me.b_mmoins.TabIndex = 30
        Me.b_mmoins.Text = "M-"
        Me.b_mmoins.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(214, 217)
        Me.Controls.Add(Me.b_mmoins)
        Me.Controls.Add(Me.b_mplus)
        Me.Controls.Add(Me.b_ms)
        Me.Controls.Add(Me.b_mr)
        Me.Controls.Add(Me.b_mc)
        Me.Controls.Add(Me.tb_buffer)
        Me.Controls.Add(Me.b_equal)
        Me.Controls.Add(Me.b_inverse)
        Me.Controls.Add(Me.b_pourcent)
        Me.Controls.Add(Me.b_sqrt)
        Me.Controls.Add(Me.b_c)
        Me.Controls.Add(Me.b_ce)
        Me.Controls.Add(Me.b_back)
        Me.Controls.Add(Me.b_plus)
        Me.Controls.Add(Me.b_minus)
        Me.Controls.Add(Me.b_star)
        Me.Controls.Add(Me.b_slash)
        Me.Controls.Add(Me.b_changesign)
        Me.Controls.Add(Me.b_coma)
        Me.Controls.Add(Me.b_zero)
        Me.Controls.Add(Me.b_three)
        Me.Controls.Add(Me.b_six)
        Me.Controls.Add(Me.b_nine)
        Me.Controls.Add(Me.b_two)
        Me.Controls.Add(Me.b_five)
        Me.Controls.Add(Me.b_eight)
        Me.Controls.Add(Me.b_one)
        Me.Controls.Add(Me.b_four)
        Me.Controls.Add(Me.b_seven)
        Me.Controls.Add(Me.tb_result)
        Me.Name = "Form1"
        Me.Text = "Calculatrice"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend result(3) As Double

    ' + 1 0 rien 8 =
    ' - 2 5 1/x
    ' * 3 6 sqrt
    ' / 4 7 +/-
    Friend operand As Integer
    Friend equal_activated As Boolean
    Friend memory As Double
    Friend equal As Double

    ' Interface ZONE : Pas touchéééé
    Friend WithEvents tb_result As System.Windows.Forms.TextBox
    Friend WithEvents b_seven As System.Windows.Forms.Button
    Friend WithEvents b_four As System.Windows.Forms.Button
    Friend WithEvents b_one As System.Windows.Forms.Button
    Friend WithEvents b_eight As System.Windows.Forms.Button
    Friend WithEvents b_five As System.Windows.Forms.Button
    Friend WithEvents b_two As System.Windows.Forms.Button
    Friend WithEvents b_nine As System.Windows.Forms.Button
    Friend WithEvents b_six As System.Windows.Forms.Button
    Friend WithEvents b_three As System.Windows.Forms.Button
    Friend WithEvents b_zero As System.Windows.Forms.Button
    Friend WithEvents b_coma As System.Windows.Forms.Button
    Friend WithEvents b_changesign As System.Windows.Forms.Button
    Friend WithEvents b_slash As System.Windows.Forms.Button
    Friend WithEvents b_star As System.Windows.Forms.Button
    Friend WithEvents b_minus As System.Windows.Forms.Button
    Friend WithEvents b_plus As System.Windows.Forms.Button
    Friend WithEvents b_back As System.Windows.Forms.Button
    Friend WithEvents b_ce As System.Windows.Forms.Button
    Friend WithEvents b_c As System.Windows.Forms.Button
    Friend WithEvents b_equal As System.Windows.Forms.Button
    Friend WithEvents b_inverse As System.Windows.Forms.Button
    Friend WithEvents b_pourcent As System.Windows.Forms.Button
    Friend WithEvents b_sqrt As System.Windows.Forms.Button
    Friend WithEvents tb_buffer As System.Windows.Forms.TextBox
    Friend WithEvents b_mc As System.Windows.Forms.Button
    Friend WithEvents b_mr As System.Windows.Forms.Button
    Friend WithEvents b_ms As System.Windows.Forms.Button
    Friend WithEvents b_mplus As System.Windows.Forms.Button
    Friend WithEvents b_mmoins As System.Windows.Forms.Button

End Class
